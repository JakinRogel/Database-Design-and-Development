﻿namespace DatabaseSQLMusicApp
{
    internal class Track
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Number { get; set; }
        public string VideoUrl { get; set; }
        public string Lyrics { get; set; }  

    }
}